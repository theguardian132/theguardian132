module.exports.config = {
  name: "chuicabox",
  version: "1.0.5",
   hasPermssion: 1,
    credits: "Bùi Lê Bảo Luân dựa trên 2 lệnh ping và chuilientuc =)",
    description: "Tag và chửi tất cả mọi người trong box",
    commandCategory: "group",
    usages: "chuicabox",
    cooldowns: 100,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, event, args })
{
("Bắt đầu chửi box!");
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 3000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 4000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 5000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 6000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 6500);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 7000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 7500);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 8000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 8500);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 9000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 9500);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 10000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 10500);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 11000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 11500);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 12000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 13000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 14000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 15000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 16000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 17000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 18000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 19000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 20000);
setTimeout(() => {a({body: "ra đây chơi em" + " " + name, mentions})} , 21000);
 }