module.exports.config = {
  name: "txserver",
  version: "3.0.0",
  hasPermssion: 0,
  credits: "Niio-team (Vtuan)",
  description: "no",
  commandCategory: "Game",
   usePrefix:false,
  usages: "[]",
  cooldowns: 0,
};

const fs = require("fs");
const path = require('path');
const { threadId } = require("worker_threads");
const filePath = "./modules/commands/Game/taixiu/";

if (!fs.existsSync(filePath)) fs.mkdirSync(filePath, { recursive: true });

const data = filePath + 'data/'
if (!fs.existsSync(data)) fs.mkdirSync(data, { recursive: true });

const lichsugiaodich = data + 'lichsugiaodich/'
if (!fs.existsSync(lichsugiaodich)) fs.mkdirSync(lichsugiaodich, { recursive: true });

const betHistoryPath = data + 'betHistory/';
if (!fs.existsSync(betHistoryPath)) fs.mkdirSync(betHistoryPath, { recursive: true });

const moneyFile = filePath + 'money.json';
const phiênFile = filePath + 'phiên.json';
// const phiên_OFFFile = filePath + 'phiên_OFF.json';
const fileCheck = filePath + 'file_check.json';

if (!fs.existsSync(moneyFile)) fs.writeFileSync(moneyFile, "[]", "utf-8");
if (!fs.existsSync(phiênFile)) fs.writeFileSync(phiênFile, "[]", "utf-8");
// if (!fs.existsSync(phiên_OFFFile)) fs.writeFileSync(phiên_OFFFile, "[]", "utf-8");
if (!fs.existsSync(fileCheck)) fs.writeFileSync(fileCheck, "[]", "utf-8");
function rollDice() {
  return Math.floor(Math.random() * 6) + 1;
}
function playGame() {
  const dice1 = rollDice();
  const dice2 = rollDice();
  const dice3 = rollDice();
  const total = dice1 + dice2 + dice3;
  const result = (total >= 3 && total <= 10) ? 'xỉu' : 'tài';
  return {total,result,dice1,dice2,dice3};
}
function Number(number) {
  let strNumber = number.toString();
  let parts = strNumber.split('.');
  let integerPart = parts[0];
  let decimalPart = parts.length > 1 ? '.' + parts[1] : '';
  let pattern = /(-?\d+)(\d{3})/;
  while (pattern.test(integerPart)) {
      integerPart = integerPart.replace(pattern, '$1,$2');
  }
  return integerPart + decimalPart;
}
module.exports.run = async function ({ api, event, args, Users, Currencies,Threads }) {
  const { ADMINBOT } = global.config;
  const { messageReply, mentions, threadID, messageID, senderID } = event;
  const checkmn = JSON.parse(fs.readFileSync(moneyFile, "utf-8"));


  if (args[0] === 'set') {
      if (!ADMINBOT.includes(senderID)) return api.sendMessage(`⚠️ Bạn không có quyền sử dụng lệnh này!`, threadID);
      let uid;
      let input;
      const arg = args.slice(1).join(' ').split('|');

      if (arg[0].toLowerCase() === 'me') {
          uid = senderID;
          input = parseInt(arg[1].trim());
      } else if (messageReply) {
          uid = messageReply.senderID;
          input = parseInt(args[1].trim());
      } else if (mentions && Object.keys(mentions).length > 0) {
          uid = parseInt(Object.keys(mentions)[0]);
          input = parseInt(args[args.length - 1].trim());
      } else if (!isNaN(parseInt(arg[0]))) {
          uid = parseInt(arg[0].trim());
          input = parseInt(arg[1].trim());
      } else if (arg[0].toLowerCase() === 'all') {
          return api.sendMessage(`Chưa Update!`, threadID)
      } else {
          return api.sendMessage('⚠️ Định dạng không hợp lệ! Hãy sử dụng me|số tiền, reply số tiền, tag số tiền, hoặc uid|số tiền.', threadID);
      }

      if (isNaN(input)) {
          return api.sendMessage('⚠️ Số tiền không hợp lệ!', threadID);
      }

      const userHistoricFile = lichsugiaodich + `${uid}.json`;
      let userHistoricData = [];
      if (fs.existsSync(userHistoricFile)) {
          userHistoricData = JSON.parse(fs.readFileSync(userHistoricFile, "utf-8"));
      }

      let e = checkmn.findIndex(entry => entry.senderID == uid);
      let time = Date.now();

      if (e !== -1) {
          const historicInput = checkmn[e].input;
          checkmn[e].input += input;
          userHistoricData.push({
              senderID: parseInt(uid),
              time: time,
              input: input,
              historic_input: historicInput
          });
      } else {
          const newEntry = {
              senderID: parseInt(uid),
              input: input
          };
          checkmn.push(newEntry);
          userHistoricData.push({
              senderID: parseInt(uid),
              time: time,
              input: input,
              historic_input: 0
          });
      }

      fs.writeFileSync(moneyFile, JSON.stringify(checkmn, null, 4), 'utf-8');
      fs.writeFileSync(userHistoricFile, JSON.stringify(userHistoricData, null, 4), 'utf-8');
      const name = await Users.getNameUser(uid);
      const message = `
🌟 Successful Deposit!
--------------------------------
👤 User Name: ${name}
🔢 User ID: ${uid}
💰 Money: ${Number(input)} VNĐ
🕒 Time: ${new Date(time).toLocaleString()}
--------------------------------
🎉 Thank you for using our service!
`;
      return api.sendMessage(message, threadID);
  } else if (args[0] == 'nap') {
      const input = parseInt(args[1])
      if (input) {
      const tien_hien_co = (await Currencies.getData(senderID)).money
      if (tien_hien_co < input) {
          return api.sendMessage(`Bạn không có nhiều tiền như thế\nQuy đổi:\n100000VND = 10000VND ở trong game tx`, threadID)
      } else {
          const userHistoricFile = lichsugiaodich + `${senderID}.json`;
          let userHistoricData = [];
          if (fs.existsSync(userHistoricFile)) {
              userHistoricData = JSON.parse(fs.readFileSync(userHistoricFile, "utf-8"));
          }
          await Currencies.decreaseMoney(senderID, input);
          let e = checkmn.findIndex(entry => entry.senderID == senderID);
          let time = Date.now();

          if (e !== -1) {
              const historicInput = checkmn[e].input;
              checkmn[e].input += input/10;
              userHistoricData.push({
                  senderID: parseInt(senderID),
                  time: time,
                  input: input/10,
                  historic_input: historicInput
              });
          } else {
              const newEntry = {
                  senderID: parseInt(senderID),
                  input: input/10
              };
              checkmn.push(newEntry);
              userHistoricData.push({
                  senderID: parseInt(senderID),
                  time: time,
                  input: input/10,
                  historic_input: 0
              });
          }

          fs.writeFileSync(moneyFile, JSON.stringify(checkmn, null, 4), 'utf-8');
          fs.writeFileSync(userHistoricFile, JSON.stringify(userHistoricData, null, 4), 'utf-8');
          const name = await Users.getNameUser(senderID);
          const message = `
🌟 Successful Deposit!
  --------------------------------
👤 User Name: ${name}
🔢 User ID: ${senderID}
💰 Money: ${Number(input/10)} VNĐ
🕒 Time: ${new Date(time).toLocaleString()}
  --------------------------------
🎉 Thank you for using our service!
`;
          return api.sendMessage(message, threadID);
      }
  } else {
      api.sendMessage(`Nhập số tiền quy đổi`,threadID)
  }
  } else if (args[0] == 'pay') {
      let uid;
      let input;
      if (messageReply) {
          uid = messageReply.senderID;
          input = parseInt(args[1].trim());
      } else if (mentions && Object.keys(mentions).length > 0) {
          uid = parseInt(Object.keys(mentions)[0]);
          input = parseInt(args[args.length - 1].trim());
      }
      if (isNaN(input)) {
          return api.sendMessage('⚠️ Số tiền không hợp lệ!', threadID);
      }

      let e = checkmn.findIndex(entry => entry.senderID == uid);
      let e1 = checkmn.findIndex(entry => entry.senderID == senderID);
      if (!e || e1) return

      if (input > checkmn[e1].input) return api.sendMessage(`Bạn không đủ tiền để chuyển!`,threadID)
      if (e !== -1) {
          checkmn[e1].input -= input;
          checkmn[e].input += input;
      } else {
          const newEntry = {
              senderID: parseInt(uid),
              input: input
          };
          checkmn.push(newEntry);
      }
      fs.writeFileSync(moneyFile, JSON.stringify(checkmn, null, 4), 'utf-8');
      api.sendMessage(`${await Users.getNameUser(senderID)} đã chuyển cho ${await Users.getNameUser(uid)} ${input} VND`,threadID)

  } else if (args[0] === 'tài' || args[0] === 'xỉu') {
      const checkData = JSON.parse(fs.readFileSync(fileCheck, "utf-8"));
      const player = checkmn.find(entry => entry.senderID == senderID);

      if (!player || player.input <= 0) {
          return api.sendMessage('⚠️ Tiền thì không có mà cứ thích may rủi?', threadID);
      }

      let betAmount = args[1] ? parseInt(args[1]) : player.input;

      if (isNaN(betAmount) || betAmount <= 0) {
          return api.sendMessage('⚠️ Xin lỗi, số tiền đặt cược phải là một số hợp lệ và lớn hơn 0!', threadID);
      }

      if (betAmount > player.input) {
          return api.sendMessage(`⚠️ Xin lỗi, bạn không đủ tiền để đặt cược \nTiền hiện có:${Number(betAmount)} VNĐ!`, threadID);
      }

      if (betAmount < 1000) {
          return api.sendMessage('⚠️ Xin lỗi, số tiền đặt cược phải lớn hơn 1000 VNĐ!', threadID);
      }


      if (!checkData.includes(threadID)) {
          const ket_qua = playGame();
          const DITCONMEMAY = ket_qua.result == args[0] ? 'win' : 'lose';
          if (DITCONMEMAY == 'win') {
              player.input += betAmount;
          } else if (DITCONMEMAY == 'lose') {
              player.input -= betAmount;
          }
          fs.writeFileSync(moneyFile, JSON.stringify(checkmn, null, 4), 'utf-8');
          const e = checkmn.find(entry => entry.senderID == senderID);
          const resultMessage = `
  🎲 KẾT QUẢ ĐÁ XÚC XẮC:
  --------------------------------
  🎲 Số xúc xắc 1: ${ket_qua.dice1}
  🎲 Số xúc xắc 2: ${ket_qua.dice2}
  🎲 Số xúc xắc 3: ${ket_qua.dice3}
  🎲 Tổng điểm: ${ket_qua.total}
  --------------------------------
  🎉 Bạn đã chọn: ${args[0]}
  ✨ Kết quả: ${ket_qua.result}
  🏆 Bạn ${DITCONMEMAY == 'win' ? `thắng và nhận được ${Number(betAmount * 2)}` : `thua và mất số tiền: ${Number(betAmount)}`}
  💲 Tiền hiện có: ${Number(e.input)}
  `;
          return api.sendMessage(resultMessage, threadID);
      } else {
          if (txTime >= 45) {
              return api.sendMessage(`⌛ Hết thời gian đặt cược`, threadID);
          } else if (txTime > 50) {
              return api.sendMessage(`⌛ Vui lòng chờ phiên mới\nPhiên mới bắt đầu sau: ${60 - txTime}s`, threadID);
          }

          const phiênData = JSON.parse(fs.readFileSync(phiênFile, "utf-8"));
          const phiên = phiênData.length ? phiênData[phiênData.length - 1].phien : 1;

          const userBetFile = betHistoryPath + `${senderID}.json`;
          let userBetData = [];
          if (fs.existsSync(userBetFile)) {
              userBetData = JSON.parse(fs.readFileSync(userBetFile, "utf-8"));
          }

          const hasBet = userBetData.some(entry => entry.senderID === senderID && entry.phien === phiên);
          if (hasBet) {
              return api.sendMessage(`⚠️ Bạn chỉ được đặt cược một lần mỗi phiên.`, threadID);
          }

          player.input -= betAmount;

          userBetData.push({
              senderID: senderID,
              choice: args[0],
              betAmount: betAmount,
              phien: phiên,
              time: Date.now()
          });

          fs.writeFileSync(moneyFile, JSON.stringify(checkmn, null, 4), 'utf-8');
          fs.writeFileSync(userBetFile, JSON.stringify(userBetData, null, 4), 'utf-8');

          const ctime = new Date().toLocaleTimeString('en-US', { hour12: false });

          return api.sendMessage(`[PHIÊN: ${phiên}]\nĐã đặt cược: ${args[0]}\nSố tiền cược: ${Number(betAmount)} VNĐ\nThời gian đặt: ${ctime}\nThời gian còn lại: ${50 - txTime}s`, threadID);
      }
  }   else if (args[0] === 'on' || args[0] === 'off') {
      const checkData = JSON.parse(fs.readFileSync(fileCheck, "utf-8"));
      const { ADMINBOT } = global.config
      const dataThread = (await Threads.getData(event.threadID)).threadInfo;
      if (!dataThread.adminIDs.some(item => item.id === senderID) && !ADMINBOT.includes(senderID)) {
          return api.sendMessage('❎ Bạn không đủ quyền hạn để sử dụng!', threadID, event.messageID);
      }
      if (args[0] === 'on') {
          if (!checkData.includes(threadID)) {
              checkData.push(threadID);
              fs.writeFileSync(fileCheck, JSON.stringify(checkData, null, 4), 'utf-8');
              return api.sendMessage(`✅ Đã bật trò chơi cho nhóm này!`, threadID);
          }
      } else if (args[0] === 'off') {
          const index = checkData.indexOf(threadID);
          if (index > -1) {
              checkData.splice(index, 1);
              fs.writeFileSync(fileCheck, JSON.stringify(checkData, null, 4), 'utf-8');
              return api.sendMessage(`Đã tắt trò chơi cho nhóm này!`, threadID);
          }
      }
  } else if (args[0] == 'check') {
      const uid = messageReply && messageReply.senderID || (mentions && Object.keys(mentions).length > 0 ? Object.keys(mentions)[0] : event.senderID);
      const player = checkmn.find(entry => entry.senderID == uid);

      if (!player) {
          return api.sendMessage(`Người chơi chưa có dữ liệu!`, threadID);
      }

      const playerName = await Users.getNameUser(uid);
      api.sendMessage(`Name: ${playerName}\nMoney: ${Number(player.input)}\nThả '👍' để xem lịch sử đặt cược`, threadID, (err, info) => {
          global.client.handleReaction.push({
              name: module.exports.config.name,
              messageID: info.messageID,
              at: senderID,
              cc: uid,
              type: 'check'
          });
      });
  } else {
      api.sendMessage(`[ Tài Xỉu ]\n+tx on/off để bật/tắt sever trong nhóm!!\n+tx tài/xỉu + số tiền/all\nChú Ý: sever liên kết với tất cả các nhóm!!`, threadID);
  }
}
module.exports.handleReaction = async function ({ api, event, handleReaction, Users }) {
  if (handleReaction.type === 'check' && event.reaction === '👍') {
      api.unsendMessage(handleReaction.messageID);

      const userBetPath = `${betHistoryPath}${handleReaction.cc}.json`;
      if (!fs.existsSync(userBetPath)) return api.sendMessage(`Người dùng chưa có dữ liệu!`, event.threadID);

      const betData = JSON.parse(fs.readFileSync(userBetPath, "utf-8")).slice(-7);
      const resultData = JSON.parse(fs.readFileSync(phiênFile, "utf-8")).slice(-7);

      const comparisons = betData.map(bet => {
          const result = resultData.find(res => res.phien === bet.phien) || { result: 'N/A' };
          const win = bet.choice === result.result;
          return {
              phien: bet.phien,
              choice: bet.choice,
              result: result.result,
              amount: bet.betAmount,
              win
          };
      });

      const msg = comparisons.map(res => `
Phiên ${res.phien}:
- Lựa chọn: ${res.choice}
- Số tiền cược: ${Number(res.amount).toLocaleString()} VNĐ
- Kết quả: ${res.win ? 'Thắng' : 'Thua'}
      `).join('\n');

      return api.sendMessage(`KẾT QUẢ CÁC CƯỢC:
--------------------------------
${msg}
`, event.threadID);
  }
};