const fs = require("fs-extra");
module.exports.config = {
    name: "mode",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Heo Rừng", 
    description: "Thay đổi mode của handleCommandNotExist",
    commandCategory: "Warthog-12",
    cooldowns: 5
};


module.exports.handleReply = async ({ event, api, handleReply, Currencies, getText }) => {
try {
    const { threadID, messageID, senderID } = event;
const configData = require('config.json');
var msg = "";
    switch(handleReply.type) {
        case "choosee": {
            
            switch(event.body) {
                case "1": 
                       configData.mode.typeImage == "loli";
                       msg = `✅Đã chuyển đổi thành loli`; break;
                case "2": 
                      configData.mode.typeImage == "lewd";
                      msg = `✅Đã chuyển đổi thành lewd`; break;
                case "3": 
                      configData.mode.typeImage == "anime";
                      msg = `✅Đã chuyển đổi thành anime`; break;
                case "4": 
                      configData.mode.typeImage == "girl";
                      msg = `✅Đã chuyển đổi thành girl`; break;
                case "5": 
                      configData.mode.typeImage == "rule34";
                      msg = `✅Đã chuyển đổi thành rule34` ; break;
                case "6": 
                      configData.mode.typeImage == "ahegao";
                      msg = `✅Đã chuyển đổi thành ahegao`; break;
                case "7": 
                      configData.mode.typeImage == "video";
                      msg = `✅Đã chuyển đổi thành video`; break;
                default: break;
            };
            const choose = parseInt(event.body);
            if (isNaN(event.body)) return api.sendMessage("⚡️Vui lòng nhập 1 con số", event.threadID, event.messageID);
            if (choose > 7 || choose < 1) return api.sendMessage("⚡️Lựa chọn không nằm trong danh sách.", event.threadID, event.messageID); //thay số case vào số 7
            api.unsendMessage(handleReply.messageID);
            return api.sendMessage(`${msg}`, event.threadID, event.messageID);

    };
}
} catch (e) {
    console.log(e)
}
    
}
module.exports.run = async ({  event, api, handleReply, Currencies, getText }) => {
    const { threadID, messageID, senderID } = event;
  const configData = require('config.json');
    return api.sendMessage({body: `⚡ Warthog-12S2 Config ⚡\n\n1. loli .\n2. lewd .\n3. anime .\n4. girl.\n5. rule34 \n6. ahegao \n7. video\n\n⚡️Hãy reply tin nhắn và chọn theo số để chuyển chế độ\n____________\n Chế độ hiện tại: ` + configData.mode.typeImage}, event.threadID, (error, info) => {
                
        global.client.handleReply.push({
            type: "choosee",
            name: this.config.name,
            author: event.senderID,
            messageID: info.messageID
          })  
        })
    
}

