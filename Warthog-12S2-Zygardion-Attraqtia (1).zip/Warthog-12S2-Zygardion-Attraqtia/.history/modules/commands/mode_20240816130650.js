const fs = require("fs-extra");
module.exports.config = {
    name: "mode",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Heo Rừng", 
    description: "Thay đổi mode của handleCommandNotExist",
    commandCategory: "Warthog-12",
    cooldowns: 5
};


module.exports.handleReply = async ({ event, api, handleReply, Currencies, getText }) => {
    const { threadID, messageID, senderID } = event;
const configData = require('./../../config.json');
var msg = "";
    switch(handleReply.type) {
        case "choosee": {
            
            switch(event.body) {
                case "1": msg = `✅Đã chuyển đổi thành loli` ;configData.mode.typeImage == "loli" ; break;             
                case "2": msg = `✅Đã chuyển đổi thành lewd`;configData.mode.typeImage == "lewd"  ; break;
                case "3": msg = `✅Đã chuyển đổi thành anime`;configData.mode.typeImage == "anime"  ; break;
                case "4": msg = `✅Đã chuyển đổi thành girl`;configData.mode.typeImage == "girl"  ; break;
                case "5": msg = `✅Đã chuyển đổi thành rule34` ;configData.mode.typeImage == "rule34"  ; break;
                case "6": msg = `✅Đã chuyển đổi thành ahegao`;configData.mode.typeImage == "ahegao"  ; break;
                case "7": msg = `✅Đã chuyển đổi thành video`;configData.mode.typeImage == "video"  ; break;
                default: break;
            };
            const choose = parseInt(event.body);
            if (isNaN(event.body)) return api.sendMessage("⚡️Vui lòng nhập 1 con số", event.threadID, event.messageID);
            if (choose > 7 || choose < 1) return api.sendMessage("⚡️Lựa chọn không nằm trong danh sách.", event.threadID, event.messageID); //thay số case vào số 7
            api.unsendMessage(handleReply.messageID);
            return api.sendMessage(`${msg}`, event.threadID, event.messageID);

    };
}
}
module.exports.run = async ({  event, api, handleReply, Currencies, getText }) => {
    const { threadID, messageID, senderID } = event;
  const configData = require('./../../config.json');
    return api.sendMessage({body: `⚡ Warthog-12S2 Config ⚡\n\n1. loli .\n2. lewd .\n3. anime .\n4. girl.\n5. rule34 \n6. ahegao \n7. video\n\n⚡️Hãy reply tin nhắn và chọn theo số để chuyển chế độ\n____________\n Chế độ hiện tại: ` + configData.mode.typeImage}, event.threadID, (error, info) => {
                
        global.client.handleReply.push({
            type: "choosee",
            name: this.config.name,
            author: event.senderID,
            messageID: info.messageID
          })  
        })
    
}

