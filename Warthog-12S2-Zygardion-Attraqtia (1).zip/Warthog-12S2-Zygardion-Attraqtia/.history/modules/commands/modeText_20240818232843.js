const fs = require("fs-extra");
module.exports.config = {
    name: "modetext",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "Heo Rừng", 
    description: "Thay đổi text của handleCommandNotExist",
    commandCategory: "Warthog-12",
    cooldowns: 5
};


module.exports.handleReply = async ({ event, api, handleReply, Currencies, getText }) => {
try {
    const { threadID, messageID, senderID } = event;
const configData = require('./../../includes/imageConfig/imageConfig.json');
    switch(handleReply.type) {
        case "text": {
            const settext = event.body;
            configData.text = settext;
            api.unsendMessage(handleReply.messageID);
            return api.sendMessage(`${settext}`, event.threadID, event.messageID);

    };
}
} catch (e) {
    console.log(e)
}
    
}
module.exports.run = async ({  event, api, handleReply, Currencies, getText }) => {
    try {
        const { threadID, messageID, senderID } = event;
  const configData = require('./../../includes/imageConfig/imageConfig.json');
    return api.sendMessage({body: `⚡ Warthog-12S2 Config ⚡\n\n⚡️Hãy reply tin nhắn để thay đổi tin nhắn của handleCommandNotExist\n____________\n Tin nhắn hiện tại: ` + configData.text}, event.threadID, (error, info) => {
                
        global.client.handleReply.push({
            type: "text",
            name: this.config.name,
            author: event.senderID,
            messageID: info.messageID
          })  
        })
    
    } catch (error) {
        console.log(error)
    }
    
}

