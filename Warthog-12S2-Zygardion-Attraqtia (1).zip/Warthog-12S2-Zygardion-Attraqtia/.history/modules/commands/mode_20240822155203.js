const fs = require("fs-extra");
module.exports.config = {
    name: "mode",
    version: "2.0.0",
    hasPermssion: 2,
    credits: "Heo Rừng", 
    description: "Thay đổi mode của handleCommandNotExist",
    commandCategory: "Warthog-12",
    cooldowns: 5
};


module.exports.handleReply = async ({ event, api, handleReply, Currencies, getText }) => {
try {
    const { threadID, messageID, senderID } = event;
const configData = require('./../../includes/imageConfig/imageConfig.json');
var msg = "";
    switch(handleReply.type) {
        case "image": {
            switch(event.body) {
                case "1": 
                       configData.mode.typeImage = "loli";
                       fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                       msg = `✅Đã chuyển đổi thành loli`; break;
                case "2": 
                      configData.mode.typeImage = "lewd";
                      fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                      msg = `✅Đã chuyển đổi thành lewd`; break;
                case "3": 
                      configData.mode.typeImage = "anime";
                      fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                      msg = `✅Đã chuyển đổi thành anime`; break;
                case "4": 
                      configData.mode.typeImage = "girl";
                      fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                      msg = `✅Đã chuyển đổi thành girl`; break;
                case "5": 
                      configData.mode.typeImage = "rule34";
                      fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                      msg = `✅Đã chuyển đổi thành rule34` ; break;
                case "6": 
                      configData.mode.typeImage = "ahegao";
                      fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                      msg = `✅Đã chuyển đổi thành ahegao`; break;
                case "7": 
                      configData.mode.typeImage = "video";
                      fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                      msg = `✅Đã chuyển đổi thành video`; break;
                case "8": 
                       configData.mode.typeImage = "custom";
                       fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                       msg = `✅Đã chuyển đổi thành custom`; break;
                default: break;
            };
            const choose = parseInt(event.body);
            if (isNaN(event.body)) return api.sendMessage("⚡️Vui lòng nhập 1 con số", event.threadID, event.messageID);
            if (choose > 7 || choose < 1) return api.sendMessage("⚡️Lựa chọn không nằm trong danh sách.", event.threadID, event.messageID); //thay số case vào số 7
            api.unsendMessage(handleReply.messageID);
            return api.sendMessage(`${msg}`, event.threadID, event.messageID);

    };
         case "text": {
                        const settext = event.body;
                        configData.text = settext;
                        fs.writeFileSync(__dirname + "./../../includes/imageConfig/imageConfig.json", JSON.stringify(configData, null, 4));
                        api.unsendMessage(handleReply.messageID);
                        return api.sendMessage(`Đã chuyển đổi thành:\n"${settext}"`, event.threadID, event.messageID);
            
                };

}
} catch (e) {
    console.log(e)
}
    
}
module.exports.run = async ({  event, api, handleReply, Currencies, getText, args }) => {
    try {
        const { threadID, messageID, senderID } = event;
  const configData = require('./../../includes/imageConfig/imageConfig.json');
  const config = require('./../../config.json');
        switch(args[0]) {
            case "image":
                return api.sendMessage({body: `⚡ Warthog-12S2 Config ⚡\n\n1. loli .\n2. lewd .\n3. anime .\n4. girl.\n5. rule34 \n6. ahegao \n7. video\n8. custom\n\n⚡️Hãy reply tin nhắn và chọn theo số để chuyển chế độ\n____________\n Chế độ hiện tại: ` + configData.mode.typeImage}, event.threadID, (error, info) => {
                
                            global.client.handleReply.push({
                                type: "image",
                                name: this.config.name,
                                author: event.senderID,
                                messageID: info.messageID
                              })  
                            })
            case "text":
                return api.sendMessage({body: `⚡ Warthog-12S2 Config ⚡\n_________________\n⚡️Hãy reply tin nhắn để thay đổi tin nhắn của handleCommandNotExist\n____________\n Tin nhắn hiện tại: ` + configData.text}, event.threadID, (error, info) => {
                
                            global.client.handleReply.push({
                                type: "text",
                                name: this.config.name,
                                author: event.senderID,
                                messageID: info.messageID
                              })   
                            })
            case "info":
                 return api.sendMessage({body: `⚡ Warthog-12S2 Config Info⚡\n_________________\n⚡️Tên bot hiện tại: ${config.BOTNAME}\nPrefix hiện tại: ${config.PREFIX}\nChế độ ảnh: ${configData.mode.typeImage}\n____________\n Tin nhắn hiện tại: ${configData.text}`}, event.threadID, event.messageID)
            default:
                return api.sendMessage("⚡ Warthog-12S2 Config ⚡\n\n1. image: thay đổi ảnh của CommandNotExist noti\n2. text: thay đổi text của CommandNotExist noti\n3. info: Kiểm tra cài đặt hiện tại của config\n_________________\n Nhập mode + keyword để sử dụng", event.threadID, event.messageID)
        }
    } catch (error) {
        console.log(error)
    }
}

